**** integer1.bin *****
2016-09-08-21-03-30-integer
Modules: adc, bit, cjson, file, gpio, http, i2c, net, node, ow, pwm, rtcmem, rtctime, spi, tmr, u8g, uart, wifi

**** integer2.bin *****
2016-11-13-21-16-52-integer
Modules: adc, bme280, bmp085, cjson, crypto, file, gpio, http, i2c, l3g4200d, mqtt, net, node, ow, pcm, pwm, spi, switec, tmr, u8g, uart, websocket, wifi


**** float1.bin *****
2016-09-08-21-03-30-float
Modules: adc, bit, cjson, file, gpio, http, i2c, net, node, ow, pwm, rtcmem, rtctime, spi, tmr, u8g, uart, wifi

**** float2.bin *****
2016-11-13-21-16-52-float
Modules: adc, bme280, bmp085, cjson, crypto, file, gpio, http, i2c, l3g4200d, mqtt, net, node, ow, pcm, pwm, spi, switec, tmr, u8g, uart, websocket, wifi
