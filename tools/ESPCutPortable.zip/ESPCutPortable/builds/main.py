import time
from machine import Pin
led=Pin(2,Pin.OUT)

for i in range(10):
  led.value(1)
  time.sleep(2)
  led.value(0)
  time.sleep(2)